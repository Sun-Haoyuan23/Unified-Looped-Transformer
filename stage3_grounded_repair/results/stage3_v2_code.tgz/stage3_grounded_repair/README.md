# 第三阶段：理解证据驱动的共享循环修复

本阶段检验“画到一半，先检查，再多想一次”能否改善最终图像。按技术方案先证明同状态可修复性，再训练固定修复器，最后训练收益与成本控制器。

## 实现

- `runtime.py`：官方 Show-o2 432×432、50时间节点 / 49次 Euler 速度预测、CFG=5；完全相同 float32 中途状态延续。
- `capture_repair_states.py`：保存 t≈0.345 / 0.455、原块7后的 prefix、RNG、时间网格和 CFG。基线与零适配器均要求 latent 完全相等、像素差为0。
- `evidence_encoder.py`：同一模型理解通路的目标/相反关系回答 margin 和 hidden states。L0标量、L1双 margin、L2语义隐藏表征。
- `evidence_conditioned_revisit.py`：复用原块2的权重，在原块7之后重访。只有条件分支视觉 token 被修复；首条10层路径冻结。
- `build_repair_candidates.py`：基线、普通循环、额外一次 ODE、零修复、目标/反向语义注入、目标/反向提示强化。
- `evaluate_oracle_pipeline.py`：官方 GenEval、PickScore、HPSv2、SigLIP，全部用原始提示评分。
- `train_repair_operator.py`：从训练集同状态终图正向延续蒸馏修复器，完整剩余轨迹反传，穿插基线正确态保真。

## 零干预与共享计算

零 FiLM 不保证额外 Transformer 为恒等映射。实际公式：

`h_new = h + visual_cond_mask * [F(h + gamma * LN(h) + beta) - F(h)]`

F 两次调用共享原始权重，gamma/beta 初始为0。冻结 F 参数仍允许梯度进入证据调制器。额外两次 F 须计入成本；当前没有降低总参数或 FLOPs 的结果。

## 数据隔离与训练门槛

结构开发12提示×2种子×2中途状态，48状态、8动作、384图。bootstrap 按12提示聚类。训练120条新增平衡空间提示、验证40官方提示、封存测试36官方提示；manifest在服务器 `splits_v1`。旧12/14提示只用于开发。新增提示与官方数据共享对象词汇及规则，须披露。

教师必须来自 train split、相同 state fingerprint，并满足官方语义错误→正确、HPS和PickScore均不下降；同时保留实际基线正确态。提示强化仅作为离线教师接口；学习后的条件共享循环须在独立验证集产生收益。终图择优的 Oracle 是上界。

训练损失是成功教师的终点 latent 蒸馏、终点距离排序与正确态保真，不是可微 GenEval 或人类偏好评价。固定修复器验证通过后才进入 controller。

## 复现、成本与证据范围

新实验冻结代码/配置、checkpoint、图像和终点文件 hash；变化必须另开目录。打乱证据来自同 split、同 flow step、另一提示。梯度检查点绑定每一步的时间、层列表及证据。

记录速度调用、视觉块调用、重访次数、剩余延续耗时与参数。FLOPs 未测为 null。prefix 和 MMU 在 Oracle 预计算，剩余延续成本不能当作端到端成本。额外 ODE 对照只在首个区间增加一次预测，尚未严格匹配循环 FLOPs。

空间修复是机制验证入口。FID/FVD、广域 GenEval、真实人类偏好、多样性及理解能力反向提升仍需后续实验。冻结理解权重尚不能证明理解能力改善。
